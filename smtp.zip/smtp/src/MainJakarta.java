import java.util.Properties;
import jakarta.mail.*;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

public class MainJakarta {
    public static void main(String[] args) throws MessagingException {

        Properties props = new Properties();
        props.put("mail.smtp.port", 25);
        props.put("mail.smtp.host", "mariobros.damiansu.com");

        Session session = Session.getDefaultInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("hola@mariobros.damiansu.com","1234");
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("hola@mariobros.damiansu.com"));
        message.setRecipient(Message.RecipientType.TO,new InternetAddress("hola@maribros.damiansu.com"));
        message.setSubject("probando desde Jakarta");
        message.setText("1,2,3... avance");

        Transport.send(message);
        System.out.println("Correo enviado");
    }
}
